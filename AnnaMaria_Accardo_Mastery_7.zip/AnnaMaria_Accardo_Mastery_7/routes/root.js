var express = require('express');
var router = express.Router();

//Route the mass of albums
router.route('/')
    .get(function (req, res, next) {
        if(sessionStorage.userID) {
            var content = {
                "title": "Library",
                "user": {
                    "firstName": "Paolo",
                    "lastName": "Angelini"
                },
                "playing": {
                    "title": "Painkiller",
                    "artist": "KeygenKaotic",
                    "duration": 180
                },
                "login": {
                    "status": "Logged in"
                },
                "tracks": [
                    {
                        "title": "Something in your mouth",
                        "artist": "Me",
                        "album": "Something elese",
                        "duration": 300
                    },
                    {
                        "title": "Something in your eyes",
                        "artist": "You",
                        "album": "Something else",
                        "duration": 240
                    }
                ],
                "playlists": [
                    {
                        "title": "Playlist1"
                    },
                    {
                        "title": "Playlist22"
                    }
                ]
            }
            console.log(content);

            console.log("html served");
            var model = content;
            res.render('library', model);
        }
        else{
            model = {};
            res.render('login', model);
        }

    });

module.exports = router;
