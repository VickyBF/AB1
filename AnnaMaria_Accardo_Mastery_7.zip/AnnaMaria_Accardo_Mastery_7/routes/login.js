var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
require('../models/User.js');
var User = mongoose.model('User');
require('../models/Playlist.js');
var Playlist = mongoose.model('Playlist');

//Route the mass of albums
router.route('/')
    .get(function (req, res, next) {

            model = {};
            res.render('login', model);


    });

router.route('/register')
    .get(function (req, res, next) {

        model = {};
        res.render('register', model);


    })
    .post(function(req, res, next) {
        var user = new User();
        user.userName = req.body.userName;
        user.firstName = req.body.firstName;
        user.lastName = req.body.lastName;
        user.password = req.body.password;
        user.email = req.body.email;
        user.playlist = req.body.playlist;
        user.save(function(err) {
            if (err) {
                res.status(400).json({});
                res.end();
            }else {
                res.statusCode = 201;
                user.password = undefined;
                res.json(user);
            }
        });
});

module.exports = router;
