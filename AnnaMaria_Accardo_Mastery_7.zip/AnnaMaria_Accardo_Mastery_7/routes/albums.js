var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
require('../models/Album.js');
var Album = mongoose.model('Album');

//Route the mass of albums
router.route('/')
    .get(function (req, res, next){
        console.log("Getting a list of all albums");
        Album.find({}).populate('artist').exec(function(err, albums) {
            if (err)
                res.send(err);
            res.json(albums);
        });
    })
    .post(function(req, res, next) {
        var album = new Album();
        album.name = req.body.name;
        album.artist = req.body.artist;
        album.artwork = req.body.artwork;
        album.label =req.body.label;
        album.tracks = req.body.tracks;
        album.dateCreated = req.body.dateCreated;
        album.dateReleased = req.body.dateReleased;
        album.save(function(err) {
            if (err) {
                res.statusCode = 400;
                res.end();
            }else {

                res.statusCode = 201;
                res.json(album);
            }
        });
    });
//Route a single album
router.route('/:id')
    .get(function(req, res) {
        Album.find({_id :req.params.id}).populate('artist').exec(function(err, album) {
            if (err) {
                res.statusCode = 404;
                res.end();
            }else if(!album){
                res.statusCode = 404;
                res.end();
            }else {
                res.json(album);
            }
        });
    })
    .put(function(req, res) {

        Album.findById(req.params.id, function(err, album) {

            if (err) {
                res.statusCode = 404;
                res.end();
            }else if(!album){
                var album = new Album();
                album._id = req.params.id;
                var neu = 1;
            }

                album.name = req.body.name;
                album.artist = req.body.artist;
                album.artwork = req.body.artwork;
                album.label = req.body.label;
                album.tracks = req.body.tracks;
                album.dateCreated = req.body.dateCreated;
                album.dateReleased = req.body.dateReleased;

                album.save(function (err) {
                    if (err) {
                        res.statusCode = 400;
                        res.end();
                    }else {
                        if(neu == 1){
                            res.statusCode = 201;
                            res.json(album);
                        }else {
                            res.statusCode = 204;
                            res.end();
                        }
                    }
                });

        });
    })
    .delete(function(req, res) {
        Album.findById(req.params.id, function (err, album) {
            if (!album) {
                res.statusCode = 404;
                res.end();
            } else {
                Album.remove({
                    _id: req.params.id
                }, function (err, album) {
                    if (err) {
                        res.statusCode = 404;
                        res.end();
                    } else {

                        res.statusCode = 204;
                        res.end();
                    }

                });

            }


        });
    });

module.exports = router;
