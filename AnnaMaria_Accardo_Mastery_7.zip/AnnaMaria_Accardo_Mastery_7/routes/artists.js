var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
require('../models/Artist.js');
var Artist = mongoose.model('Artist');

//Route the mass of artists
router.route('/')
    .get(function (req, res, next){
        console.log("Getting a list of all artists");
        Artist.find({},function(err, artists) {
            if (err)
                res.send(err);
            res.json(artists);
        });
    })
    .post(function(req, res, next) {
        var artist = new Artist();
        artist.name = req.body.name;
        artist.genre = req.body.genre;
        artist.artwork = req.body.artwork;
        artist.dateCreated = req.body.dateCreated;
        artist.save(function(err) {
            if (err) {
                res.statusCode = 400;
                res.end();
            }else {
                res.statusCode = 201;
                res.json(artist);
            }
        });
    });
//Route a single artist
router.route('/:id')
    .get(function(req, res) {
        Artist.findById(req.params.id, function(err, artist) {
            if (err) {
                res.statusCode = 404;
                res.end();
            }
            if(!artist){
                res.statusCode = 404;
                res.end()
            }else {
                res.json(artist);
            }
        });
    })
    .put(function(req, res) {

        Artist.findById(req.params.id, function(err, artist) {

            if (err){
                res.statusCode = 404;
                res.end();
            }else if(!artist){
                var artist = new Artist();
                artist._id = req.params.id;
                var neu = 1;
            }

            artist.name = req.body.name;
            artist.genre = req.body.genre;
            artist.artwork = req.body.artwork;
            artist.dateCreated = req.body.dateCreated;

            artist.save(function(err) {
                if (err) {
                    res.statusCode = 400;
                    res.end();
                }else {
                    if (neu == 1) {
                        res.statusCode = 201;
                        res.json(artist);
                    } else {
                        res.statusCode = 204;
                        res.end();
                    }
                }
            });

        });
    })
    .delete(function(req, res) {
        Artist.findById(req.params.id, function (err, artist) {
            if (!artist) {
                res.statusCode = 404;
                res.end();
            } else {
                Artist.remove({
                    _id: req.params.id
                }, function (err, artist) {
                    if (err) {
                        res.statusCode = 404;
                        res.end();
                    } else {

                        res.statusCode = 204;
                        res.end();
                    }

                });

            }


        });
    });
module.exports = router;
