var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
require('../models/User.js');
var User = mongoose.model('User');
require('../models/Playlist.js');
var Playlist = mongoose.model('Playlist');

//Route the mass of users
router.route('/')
    .get(function (req, res, next){
        console.log("Getting a list of all users");
        User.find({},{password : 0}).populate('playlists').exec(function(err, users) {
            if (err)
                res.send(err);
            res.json(users);
        });
    })
    .post(function(req, res, next) {
        var user = new User();
        user.userName = req.body.userName;
        user.firstName = req.body.firstName;
        user.lastName = req.body.lastName;
        user.password = req.body.password;
        user.email = req.body.email;
        user.playlist = req.body.playlist;
        user.save(function(err) {
            if (err) {
                console.log(err);
                res.status(400).json({});
                res.end();
            }else {
                res.statusCode = 201;
                user.password = undefined;
                res.json(user);
            }
        });
    });
//Route a single user
router.route('/:id')
    .get(function(req, res) {
        User.findById(req.params.id,{password : 0}, function(err, user) {
            if (err) {
                res.statusCode = 404;
                res.end();
            }
            if(!user){
                res.statusCode = 404;
                res.end()
            }else {
                res.json(user);
            }

        });
    })
    .put(function(req, res) {

        User.findById(req.params.id, function(err, user) {

            if (err) {
                res.statusCode = 404;
                res.send(err);
            }
            else if(!user){
                var user = new User();
                user._id = req.params.id;
                var neu = 1;
            }


                user.userName = req.body.userName;
                user.firstName = req.body.firstName;
                user.lastName = req.body.lastName;
                user.password = req.body.password;
                user.email = req.body.email;
                user.playlist = req.body.playlist;

            user.save(function(err) {
                if (err) {
                    res.status(400).json({});
                    res.end();
                }else {
                    if (neu == 1) {
                        res.statusCode = 201;
                        user.password = undefined;
                        res.json(user);
                    } else {
                        res.statusCode = 204;
                        res.end();
                    }
                }
            });
        });
    })
    .delete(function(req, res) {
        User.findById(req.params.id, function (err, user) {
            if (!user) {
                res.statusCode = 404;
                res.end();
            } else {
                User.remove({
                    _id: req.params.id
                }, function (err, user) {
                    if (err) {
                        res.statusCode = 404;
                        res.end();
                    } else {

                        res.statusCode = 204;
                        res.end();
                    }

                });

            }


        });
    });
router.route('/:userid/playlists')
    .get(function(req, res) {
      console.log("a playlist request");
      console.log(req.params.userid);
      console.log("Getting a list of all users playlists");
      User.findById(req.params.userid,{playlists:1},function(err, playlists) {
          if (err) {
              res.statusCode = 404;
              res.end();
          }
          if(!playlists){
              res.statusCode = 404;
              res.end();
          }else {
              res.json(playlists);
          }
      });
     })
    .put(function(req, res) {

        User.findById(req.params.userid,{playlists:1}, function (err, user) {

            if (err) {
                res.statusCode = 400;
                res.end();
            }
            if(!user){
                res.statusCode = 400;
                res.end();
            }else {

                user.playlists = req.body;


                user.save(function (err) {
                    if (err) {
                        res.statusCode = 400;
                        res.end();
                    } else {
                        res.statusCode = 204;
                        res.end();
                    }
                });
            }
        });
    });
router.route('/:username/:password')
    .get(function(req, res) {

    User.findOne({userName : req.param.userName},function(err, user) {
        if (err) {
            res.statusCode = 404;
            res.end();
        }

        else {
            if(user.password == req.param.password) {
                user.password = null;
                res.json(user);
            }else{
                res.statusCode = 401;
                res.end();
            }
        }
    });
})


module.exports = router;
