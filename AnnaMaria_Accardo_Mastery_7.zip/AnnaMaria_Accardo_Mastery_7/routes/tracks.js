var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
require('../models/Track.js');
var Track = mongoose.model('Track');

//Route the mass of tracks
router.route('/')
    .get(function (req, res, next){
        console.log("Getting a list of all tracks");
        Track.find({}).populate('artist').populate('album').exec(function(err, tracks) {
            if (err)
                res.send(err);
            res.json(tracks);
        });
    })
    .post(function(req, res, next) {
        var track = new Track();
        track.name = req.body.name;
        track.artist = req.body.artist;
        track.duration = req.body.duration;
        track.file = req.body.file;
        track.album = req.body.album;
        track.id3Tags = req.body.id3Tags;
        track.dateReleased = req.body.dateReleased;
        track.dateCreated = req.body.dateCreated;
        track.save(function(err) {
            if (err) {
                res.statusCode = 400;
                res.end();
            }else {

                res.statusCode = 201;
                res.json(track);
            }
        });
    });
//Route a single track
router.route('/:id')
    .get(function(req, res) {
        Track.findById(req.params.id, function(err, track) {
            if (err) {
                res.statusCode = 404;
                res.end();
            }
            if(!track){
                res.statusCode = 404;
                res.end();
            }else {
                res.json(track);
            }
        });
    })
    .put(function(req, res) {

        Track.findById(req.params.id, function(err, track) {

            if (err) {
                res.statusCode = 404;
                res.end();
            }else if(!track){
                var track = new Track();
                track._id = req.params.id;
                var neu = 1;
            }


                track.name = req.body.name;
                track.artist = req.body.artist;
                track.duration = req.body.duration;
                track.file = req.body.file;
                track.album = req.body.album;
                track.id3Tags = req.body.id3Tags;
                track.dateReleased = req.body.dateReleased;
                track.dateCreated = req.body.dateCreated;

                track.save(function (err) {
                    if (err) {
                        res.statusCode = 400;
                        res.end();
                    }else {
                        if (neu == 1) {
                            res.statusCode = 201;
                            res.json(track);
                        } else {
                            res.statusCode = 204;
                            res.end();
                        }
                    }
                });

        });
    })
    .delete(function(req, res) {
        Track.findById(req.params.id, function (err, track) {
            if (!track) {
                res.statusCode = 404;
                res.end();
            } else {
                Track.remove({
                    _id: req.params.id
                }, function (err, track) {
                    if (err) {
                        res.statusCode = 404;
                        res.end();
                    } else {

                        res.statusCode = 204;
                        res.end();
                    }

                });

            }


        });
    });
router.route('/album/:albumid')
    .get(function(req, res) {
        Track.find({album:req.params.albumid}).populate('album').populate('artist').exec(function(err, track) {
            if (err) {
                res.statusCode = 404;
                res.end();
            }
            if(!track){
                res.statusCode = 404;
                res.end();
            }else {
                res.json(track);
            }
        });
    })
router.route('/artist/:artistid')
    .get(function(req, res) {
        Track.find({artist:req.params.artistid}).populate('album').populate('artist').exec(function(err, track) {
            if (err) {
                res.statusCode = 404;
                res.end();
            }
            if(!track){
                res.statusCode = 404;
                res.end();
            }else {
                res.json(track);
            }
        });
    })

module.exports = router;
