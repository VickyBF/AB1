var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
require('../models/Playlist.js');
var Playlist = mongoose.model('Playlist');


//Route a single playlist
router.route('/')
    .get(function (req, res, next){
        console.log(req.params);
        console.log(req.params.userid);
        console.log("Getting a list of all users playlists");
        Playlist.findById(req.params.userid,function(err, playlists) {
            if (err)
                res.send(err);
            res.json(playlists);
        });
    })
    .put(function(req, res) {

        Playlist.findById(req.params.id, function(err, playlist) {

            if (err)
                res.send(err);

            playlist.name = req.body.name;
            playlist.tracks = req.body.tracks;
            playlist.dateCreated = req.body.dateCreated;

            playlist.save(function(err) {
                if (err)
                    res.send(err);
                res.statusCode = 204;
                res.end();
            });
        });
    });


module.exports = router;
