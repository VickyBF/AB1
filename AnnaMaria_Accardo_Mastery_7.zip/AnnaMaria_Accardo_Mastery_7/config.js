module.exports = {
  // MongoDB
  // Url of the Mongodb server
  mongoUrl: "mongodb://localhost/",
  // Database name
  mongoDbName: "atelierbeats-dev",
  //Server URL
  url: "http://127.0.0.1:3000"
}