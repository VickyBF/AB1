
//        Quando l'oggetto è caricato automaticamente vengono fatte partire le funzioni "onload"
// Window.data mi connette alla mia finestra dati
window.onload = function(){
  window.model = window.data;


  drawView();
  setupPlaylists();
  setupSearch();
}

function drawView(){
  var body = document.getElementsByTagName('body')[0];
  // Richiama tutto il body e i suoi valori
  var classList = body.classList;
  // The classList contains = ["body", "library", item: function, contains: function, add: function, remove: function, toggle: function]
    if (classList.contains('library')){
    drawLibrary();
    setupPlayer();
  }else if (classList.contains('albums')){
    drawAlbums();
  }
  else if (classList.contains('artists')){
    drawArtists();
  }
}

function setupPlaylists(){
  loadPlaylistsFromLocalStorage();

  var createPlBtn = document.getElementById("create-pl-btn");
  createPlBtn.addEventListener('click', function(){

    localStorage.pl_cnt =  localStorage.pl_cnt || 0;
    var cnt = localStorage.pl_cnt;

    var _id = "pl-"+cnt
    var name = 'New Playlist ' + (++cnt);
    // When the Playlist is created the number is increased
    var newPlaylist =  playlist(_id, name, model.users[0]._id, []); 
// Increment the local storage
    //update localStorage counter
    localStorage.pl_cnt = cnt;
    
    //persist to localStorage
    savePlaylist(newPlaylist);
    appendNewPlaylistToMenu(newPlaylist);    
  })
// When the event occurs
  document.addEventListener('click', function (e) {
    //
    if (e.target.classList.contains('edit-btn') ) {
      return onEditPlaylistClicked(e.target)
    }

    if (e.target.classList.contains('pl-name-input') ) {
      return e.preventDefault();
    }

    if (e.target.classList.contains('pl-name') ) {
      e.preventDefault();
        // Cancella l'azione predefinita associata a un evento se l'evento lo permette,
        // senza bloccare un'ulteriore propagazione degli eventi
      return onPlaylistClicked(e.target)
    }

    //the click was outside an edit element, close currently edited ones
    var currentlyEditing = document.querySelectorAll('#playlists > li.edit .edit-btn');
    // Returns a list of the elements within the document
    for (var i = currentlyEditing.length - 1; i >= 0; i--) {
      onEditPlaylistClicked(currentlyEditing[i]);
    };

  });
}

function setupSearch(){
  var searchBox = document.getElementById("main-search");
    // Quando accade l'evento "input"
  searchBox.addEventListener("input", function(){
    var split = this.value.split(" ");

    result = fuzzyFind(model.tracks, "name", this.value);

    if(this.value.trim() === ""){
      drawLibrary();
      return;
    }


    var container = document.getElementById('tracklist');
    var classList = container.classList;
// Tabella HTML
    var newHtml = '<div class="fl-tl-thead fl-tl-row">\n\
      <div class="fl-tl-th fl-tl-name">Song</div>\n\
      <div class="fl-tl-th fl-tl-artist">Artist</div>\n\
      <div class="fl-tl-th fl-tl-album">Album</div>\n\
      <div class="fl-tl-th fl-tl-time">Time</div>\n\
    </div>';

    newHtml += createHTMLLibrary(result);

    container.innerHTML = newHtml;
  })
}

function allowDrop(evt) {
    evt.preventDefault();
    // Cancella l'azione predefinita associata a un evento se l'evento lo permette,
    // senza bloccare un'ulteriore propagazione degli eventi
}

function drag(evt) {
  evt.dataTransfer.setData("text/plain", evt.currentTarget.id);
}

function drop(evt) {
    evt.preventDefault();
    // Cancella l'azione predefinita associata a un evento se l'evento lo permette,
    // senza bloccare un'ulteriore propagazione degli eventi
    var trackId = evt.dataTransfer.getData("text/plain");
    var playlistId = evt.currentTarget.id
    addTrackToPlaylist(playlistId, trackId)
}

function addTrackToPlaylist(playlistId, trackId){
  var playlists =  JSON.parse(localStorage.playlists);
  // Parse trasforma l'oggetto tra parentesi in un JSON
  var pl = playlists[playlistId];
  if(typeof pl === "undefined"){
    throw new Error("playlist doesn't exist in localStorage")
  }

  var track = findOne(model.tracks, "_id", trackId);
  if(typeof track === "undefined" || track === null){
    throw new Error("track doesn't exist in the model")
  }

  pl.tracks.push(trackId);

  //persist
  playlists[playlistId]= pl;
    //Riporta un JSON object a stringa
  localStorage.playlists = JSON.stringify(playlists);
}

function onPlaylistClicked(link){
  localStorage.playlists = localStorage.playlists || JSON.stringify({});
  var playlists =  JSON.parse(localStorage.playlists);
  var id = link.dataset["for"];
  var playlist = playlists[id];
  var tracks = playlist.tracks;
  var container = document.getElementById('tracklist');
  var classList = container.classList;

  if (tracks.length < 1){
    return container.innerHTML = "Playlist " + playlist.name + " is empty."
  }
//Table
  var newHtml = '<div class="fl-tl-thead fl-tl-row">\n\
    <div class="fl-tl-th fl-tl-name">Song</div>\n\
    <div class="fl-tl-th fl-tl-artist">Artist</div>\n\
    <div class="fl-tl-th fl-tl-album">Album</div>\n\
    <div class="fl-tl-th fl-tl-time">Time</div>\n\
  </div>';

  tracks.forEach(function(track){
    track = findOne(model.tracks, "_id", track)
    var artist = findOne(model.artists, "_id", track.artist);
    var album = findOne(model.albums, "_id", track.album);

    newHtml+= '<div id="'+ track._id +'"" class="fl-tl-row" draggable="true">'
    newHtml+= '<div class="fl-tl-cell fl-tl-name"><a href="#">'+ track.name + '</a></div>\n';
    //replace each instance of certain characters by the UTF-8 encoding of the character
    newHtml+= '<div class="fl-tl-cell fl-tl-artist"><a href="artists/'+ encodeURI(artist.name)+ '">'+ artist.name +'</a></div>\n';
    newHtml+= '<div class="fl-tl-cell fl-tl-album"><a href="albums/'+ encodeURI(album.name)+ '">'+ album.name +'</a></div>\n';
    newHtml+= '<div class="fl-tl-cell fl-tl-time">'+ formatTime(track.duration) + '</div>\n';
    newHtml+= '</div>\n';
  })
//sets or gets the HTML syntax
  container.innerHTML = newHtml;
}

function onEditPlaylistClicked(btn){
  var id = btn.dataset["for"];
  var el = document.getElementById(id);
    //returns the first child element that matches a specified CSS selector(s) of an element
  var input = document.querySelector('#'+id + " > input[type='text']");

  if(el.classList.contains("edit")){
    el.classList.remove('edit')
     btn.innerHTML = '<i class="fa fa-pencil" ></i>'
      //returns the first child element that matches a specified CSS selector(s) of an element
     var input = document.querySelector('#'+id + " > input[type='text']");
     var nameLink =  document.querySelector('#'+id + " > .pl-name");

     //return on empty string
     if(input.value.trim() == '') return;

     nameLink.innerHTML = '<i class="nav-menu-icon fa fa-bars"></i> ' + input.value;
     nameLink.href = "playlists/" + encodeURI(input.value)

     //persist change
     var playlists =  JSON.parse(localStorage.playlists);
     playlists[id]["name"] = input.value;
     localStorage.playlists = JSON.stringify(playlists);
  }else{
    el.classList.add('edit')
    btn.innerHTML = '<i class="fa fa-check" ></i>'
    input.focus();
  }
}

function loadPlaylistsFromLocalStorage(){
  localStorage.playlists = localStorage.playlists || JSON.stringify({});
  var playlists =  JSON.parse(localStorage.playlists);
  //merge localStorage playlists with model playlists
  model.playlists.forEach(function(playlist){
    if (!playlists.hasOwnProperty(playlist._id))
    playlists[playlist._id] = playlist;
  });

  var keys = Object.keys(playlists);
  var newHtml ='';
  keys.forEach(function(key){
    appendNewPlaylistToMenu(playlists[key]);
  });

  //persist playlists
  localStorage.playlists = JSON.stringify(playlists);
}

function appendNewPlaylistToMenu(pl){
  var id = pl._id;
  var name = pl.name;
    // TABLE
  var newHtml ='';
  newHtml += '  <li id="' + id + '" ondrop="drop(event)" ondragover="allowDrop(event)">';
  newHtml += '    <a class="pl-name" data-for="' + id + '" href="playlists/' + encodeURI(name) + '">';
  newHtml += '      <i class="nav-menu-icon fa fa-bars"></i>' + name;
  newHtml += '    </a>';
  newHtml += '    <a class="edit-btn" data-for="' + id + '" href="#"><i class="fa fa-pencil"></i></a>';
  newHtml += '    <input  class="pl-name-input" name="' + id + '" type="text" value="' + name + '">';
  newHtml += '  </li>';

  document.getElementById('playlists').innerHTML += newHtml;
}

function find(arr, prop, val){
  var res = [];
    //loop
  arr.forEach(function(item){
    if("undefined" !== item[prop]
        && item[prop] === val){
      res.push(item)
    }
  });
  return res;
}

function findOne(arr, prop, val){
  for (var i=0, l=arr.length; i<l; i++){
    var item = arr[i];
    if("undefined" !== item[prop]
        && item[prop] === val){
      return item;
    }
  }
}

function drawLibrary(){
  var container = document.getElementById('tracklist');
  var classList = container.classList;
//TABLE
  var newHtml = '<div class="fl-tl-thead fl-tl-row">\n\
    <div class="fl-tl-th fl-tl-name">Song</div>\n\
    <div class="fl-tl-th fl-tl-artist">Artist</div>\n\
    <div class="fl-tl-th fl-tl-album">Album</div>\n\
    <div class="fl-tl-th fl-tl-time">Time</div>\n\
  </div>';

  newHtml += createHTMLLibrary(model.tracks);

  container.innerHTML = newHtml;
}

function createHTMLLibrary(tracks){
  var newHtml = "";
  tracks.forEach(function(track){
    var artist = findOne(model.artists, "_id", track.artist);
    var album = findOne(model.albums, "_id", track.album);

    newHtml+= '<div id="'+ track._id +'"" class="fl-tl-row" draggable="true" ondragstart="drag(event)">';
    newHtml+= '<div class="fl-tl-cell fl-tl-name"><a href="#">'+ track.name + '</a></div>\n';
    newHtml+= '<div class="fl-tl-cell fl-tl-artist"><a href="artists/'+ encodeURI(artist.name)+ '">'+ artist.name +'</a></div>\n';
    newHtml+= '<div class="fl-tl-cell fl-tl-album"><a href="albums/'+ encodeURI(album.name)+ '">'+ album.name +'</a></div>\n';
    newHtml+= '<div class="fl-tl-cell fl-tl-time">'+ formatTime(track.duration) + '</div>\n';
    newHtml+= '</div>\n';
  })

  return newHtml;
}

function drawArtists(){
  var container = document.getElementById('artists');
  var classList = container.classList;
// crea la sezione in cui verrà creata la tavola
  var newHtml = '<ul class="grid-list clearfix">';

  model.artists.forEach(function(artist){
    newHtml+= '  <li>\n';
    newHtml+= '    <div class="media-object">\n';
    newHtml+= '      <div class="mo-image" style="background-image: url(\''+artist.artwork +'\')"></div>\n';
    newHtml+= '      <div class="mo-overlay"></div>\n';
    newHtml+= '    </div>\n';
    newHtml+= '    <div class="mo-info"><a href="artists/' + encodeURI(artist.name) + '">'+ artist.name + '</a></div>\n';
    newHtml+= '  </li>\n';
  })

  newHtml += '</ul>';
  container.innerHTML = newHtml;
}

function drawAlbums(){
  var container = document.getElementById('albums');
  var classList = container.classList;

  var newHtml = '<ul class="grid-list clearfix">';

  model.albums.forEach(function(album){
    var artist = findOne(model.artists, "_id", album.artist);
    newHtml+= '  <li>\n';
    newHtml+= '    <div class="media-object">\n';
    newHtml+= '      <div class="mo-image" style="background-image: url(\''+album.artwork +'\')"></div>\n';
    newHtml+= '      <div class="mo-overlay"></div>\n';
    newHtml+= '    </div>\n';
    newHtml+= '    <div class="mo-info subtitle">\n';
    newHtml+= '      <a class="mo-title" href="albums/' + encodeURI(album.name) +'">' + album.name +'</a>\n';
    newHtml+= '      <div class="mo-subtitle text-muted one-line">\n';
    newHtml+= '       <a title="Paul Simon" href="artists/' + encodeURI(artist.name) +'">' + artist.name +'</a>\n';
    newHtml+= '     </div>\n';
    newHtml+= '   </div>\n';
    newHtml+= '  </li>\n';
  })

  newHtml += '</ul>';
  container.innerHTML = newHtml;
}

function formatTime(totalSec){
    //string to int
  var hours = parseInt( totalSec / 3600 ) % 24;
  var minutes = parseInt( totalSec / 60 ) % 60;
  var seconds = totalSec % 60;

  var result = (hours < 1 ? '': hours + ':') ;
  result +=  (minutes < 1 ? "00:" : minutes + ':') ;
  result += (seconds  < 10 ? "0" + seconds : seconds);
  return result;
}

/**
* This function setups the player. More specifically:
* - It should create an audio element and append it in the body
*
* - The audio element should load by default the first track of your library
*
* - When the track is paused and you click on the play button of exercise one,
*   it should play the current track and switch the icon of the button to 'pause'.
*
* - When the track is playing the progress bar should be updated to reflect the progress
*
* - When the progress bar is clicked the current time of the player should skip to
*  the corresponding time
*
* - As the track is playing the elapsed time should be updated
*
* - Implement a volume bar that does what the progress bar does for sound but for volume.
*
* - When a track is clicked from the library, your player should start playing it
*
* - When a track finishes your player should play the next one
*/

function setupPlayer(){
  // Buttons
  var playButton = document.getElementById("play-pause");
  var muteButton = document.getElementById("mute");
  var fullScreenButton = document.getElementById("full-screen");
  var volumeOff = document.getElementById("volume-off");
  var volumeUp = document.getElementById("volume-up");

  // Sliders
  var seekRail = document.getElementById("pl-timeline-rail");
  var seekBar = document.getElementById("pl-timeline-bar");
  var volumeRail = document.getElementById("pl-volume-rail");
  var volumeBar = document.getElementById("pl-volume-bar");

  //Labels
  var timeElapsed = document.getElementById("time-elapsed");
  var timeTotal = document.getElementById("time-total");

  // Audio element
  var audio = document.createElement('audio');

  audio.addEventListener("loadedmetadata",function(){
    //set total time
    timeTotal.innerHTML = formatTime(Math.floor(audio.duration));

    //set volume
    volumeBar.style.width = (audio.volume * 100) + "%";
  })
  audio.src = 'https://archive.org/download/testmp3testfile/mpthreetest.mp3';
  document.body.appendChild(audio);


  // Event listener for the play/pause button
  playButton.addEventListener("click", function() {
    if (audio.paused == true) {
      // Play the track
      audio.play();

      // Update the button icon to 'Pause'
      playButton.classList.remove('fa-play')
      playButton.classList.add('fa-pause')
    } else {
      // Pause the track
      audio.pause();

      // Update the button icon to 'Play'
      playButton.classList.remove('fa-pause')
      playButton.classList.add('fa-play')
    }
  });

  // Event listener for the seek bar (barra di ricerca)
  seekRail.addEventListener("click", function(evt) {
    var frac = (evt.offsetX / seekRail.offsetWidth)
    seekBar.style.width = (frac * 100) + "%";

    // Calculate the new time
    var time = audio.duration * frac;
    audio.currentTime = time;
  });

  // Update the barra di ricerca as the track plays
  audio.addEventListener("timeupdate", function() {
    // Calculate the slider value
    var value = (100 / audio.duration) * audio.currentTime;

    // Update the seek bar
    seekBar.style.width = value + "%";

    // Update the elapsed time
    timeElapsed.innerHTML = formatTime(Math.floor(audio.currentTime));
  });

  // Event listener for the volume bar
  volumeRail.addEventListener("click", function(evt) {
    var frac = (evt.offsetX / volumeRail.offsetWidth)
    volumeBar.style.width = (frac * 100) + "%";

    audio.volume = frac;
  });

  //Click listener for volume buttons
  volumeOff.addEventListener("click", function(evt) {
    volumeBar.style.width = "0%";
    audio.volume = 0;

    volumeOff.classList.add("active")
    volumeUp.classList.remove("active")
  });

  volumeUp.addEventListener("click", function(evt) {
    volumeBar.style.width = "100%";
    audio.volume = 1;

    volumeUp.classList.add("active")
    volumeOff.classList.remove("active")
  });
}
