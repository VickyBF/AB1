/**
 * Created by usi on 11/7/14.
 */
var express = require('express');
var app = express();
function doJSONRequest(method, url, headers, data, callback){
    if(method !== '' && url !== '' && headers !== '' && data !== '' && callback !== '' && arguments.length == 5){
        if (method == 'GET' || method == 'POST' || method == 'PUT' || method == 'DELETE'){


            var r = new XMLHttpRequest();
            //headers = headersSet(headers.split(','));

            //open an asynchronous connection to the server using GET method on the /address/find API passing the parameters
            r.open(method, url, true);
            var toSend = null;
            if(data !== undefined && data !== null) {
                if(JSON.stringify(data) != undefined){
                    toSend = JSON.stringify(data);
                }else{
                    throw new Error;
                }

            }
            if(method == 'POST' || method == 'PUT'){

                r.setRequestHeader("Content-Type","application/json");

                console.log("PARSED" +toSend);
            }
            r.setRequestHeader("Accept","application/json");
            //wait for the response from the server
            r.onreadystatechange = function () {
                //correctly handle the errors based on the HTTP status returned by the called API
                if (r.readyState != 4 || r.status != 200) return;
                callback(JSON.parse(r.responseText))
                console.log(callback(JSON.parse(r.responseText)));
                console.log('call ended succesfully!');
            };

            //send the request to the server
            r.send(toSend);
        }
        else{
            throw new Error;
        }

    }else{
        throw new Error;
    }

}

var password = document.getElementById("password");
var repeat = document.getElementById("repeat");
function enable(){
    document.getElementById("btnPlaceOrder").disabled = password.value !== repeat.value;
}

function timeout(){
    window.setTimeout(function(){
        window.location.href = "login.html";
    }, 600000);
}
//################################################################################
function login(){
    var userName = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    console.log(userName);
    console.log(password);
    var data = {
        userName : userName,
        password : password
    };
    console.log(data, "DATA");
    doJSONRequest("POST", "/users", {}, data, function(location){
        document.location = location.location;
    });
}

function validation(){
    var userName_login = document.getElementById("username").value;
    var password_login = document.getElementById("password").value;
    var data = {
        userName : userName_login,
        password : password_login
    };
    doJSONRequest("GET", "/users/", {}, data, function(location){
        document.location = location.location;
    })
}
//############################################################################################
app.use('/users',User);